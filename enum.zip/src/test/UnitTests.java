package test;

import main.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class UnitTests {

  @Test
	void testConstruction() {
		StopLight s = new StopLight();
		// new light should be red
		assertEquals(StopLight.LightColour.RED, s.getColour());
	}
	
	@Test
	void testAdvanceREDGREEN() {
		StopLight s = new StopLight();
		// after advance a red light should be green
		s.advance();
		assertEquals(StopLight.LightColour.GREEN, s.getColour());
	}
	
	@Test
	void testAdvanceGREENAMBER() {
		StopLight s = new StopLight();
		// after advance a green light should be amber
		s.advance();
		s.advance();
		assertEquals(StopLight.LightColour.AMBER, s.getColour());
	}
	
	@Test
	void testAdvanceAMBERRED() {
		StopLight s = new StopLight();
		// after advance an amber light should be red
		s.advance();
		s.advance();
		s.advance();
		assertEquals(StopLight.LightColour.RED, s.getColour());
	}

}