package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.*;

public class DoorTest {

    @Test
	public void testSuperConstructor() {
	SuperClass s = new SuperClass();
    }

    @Test
	public void testSubConstructor() {
	SuperClass s = new SubClass();
    }

    @Test
	public void textExtension() {
	SuperClass superclass = new SuperClass();
	SubClass subclass = new SubClass();
	assertTrue(superclass instanceof SuperClass);
	assertTrue(subclass instanceof SuperClass);
	assertFalse(superclass instanceof SubClass);
    }

}