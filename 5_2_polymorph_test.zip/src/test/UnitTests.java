package test;

import main.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class UnitTests {

    @Test
    public void testMultiShape() {
	// Failure message:
	// Tested adding several different purple shapes. Check your processor
	// calculations.
	String expected = "RED:0.00 ORANGE:0.00 YELLOW:0.00 GREEN:0.00 BLUE:0.00 PURPLE:250.00  ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Square(Colour.PURPLE, 10));
	calculator.addShape(new Rectangle(Colour.PURPLE, 10, 10));
	calculator.addShape(new Triangle(Colour.PURPLE, 10, 10));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());
    }

    @Test
    public void testPurpleSquare() {
	// Failure message:
	// Tested adding a purple square. Check that your calculator is adding the
	// colour to the report string correctly (and the area of square).
	String expected = "RED:0.00 ORANGE:0.00 YELLOW:0.00 GREEN:0.00 BLUE:0.00 PURPLE:1.00  ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Square(Colour.PURPLE, 1));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());
    }

    @Test
    public void testBlueEllipse() {
	// Failure message:
	// Tested adding a blue ellipse. Check that your calculator is adding the colour
	// to the report string correctly (and the area of ellipse).
	String expected = "RED:0.00 ORANGE:0.00 YELLOW:0.00 GREEN:0.00 BLUE:157.08 PURPLE:0.00 ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Ellipse(Colour.BLUE, 10, 5));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());

    }

    @Test
    public void testGreenTriangle() {
	// Failure message:
	// Tested adding a green triangle. Check that your calculator is adding the
	// colour to the report string correctly (and the area of triangle).
	String expected = "RED:0.00 ORANGE:0.00 YELLOW:0.00 GREEN:50.00 BLUE:0.00 PURPLE:0.00 ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Triangle(Colour.GREEN, 10, 10));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());

    }

    @Test
    public void testYellowRectangle() {
	// Failure message:
	// Tested adding a yellow rectangle. Check that your calculator is adding the
	// colour to the report string correctly (and the area of rectangle).
	String expected = "RED:0.00 ORANGE:0.00 YELLOW:50.00 GREEN:0.00 BLUE:0.00 PURPLE:0.00 ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Rectangle(Colour.YELLOW, 10, 5));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());

    }

    @Test
    public void testOrangeCircle() {
	// Failure message:
	//
	// Tested adding an orange square. Check that your calculator is adding the
	// colour to the report string correctly (and the area of circle).
	String expected = "RED:0.00 ORANGE:314.16 YELLOW:0.00 GREEN:0.00 BLUE:0.00 PURPLE:0.00 ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Circle(Colour.ORANGE, 10));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());

    }

    @Test
    public void testRedSquare() {
	// Failure message:
	// Tested adding a red square. Check that your calculator is adding the colour
	// to the report string correctly (and the area of square).
	String expected = "RED:100.00 ORANGE:0.00 YELLOW:0.00 GREEN:0.00 BLUE:0.00 PURPLE:0.00 ";

	PaintCalculator calculator = new PaintCalculator();
	calculator.addShape(new Square(Colour.RED, 10));
	String report = calculator.generateReport();
	assertEquals(expected.trim(), report.trim());

    }

    @Test
    public void testPaintCalculatorEmptyReport() {
	// Failure message:
	// Check your report format, should be RED:0.00 ORANGE:0.00 YELLOW:0.00
	// GREEN:0.00 BLUE:0.00 PURPLE:0.00
	//
	// (use String.format("%.2f", colourArea)) to ensure 2 decimal digits)
	String expected = "RED:0.00 ORANGE:0.00 YELLOW:0.00 GREEN:0.00 BLUE:0.00 PURPLE:0.00 ";

	PaintCalculator calculator = new PaintCalculator();

	String report = calculator.generateReport();

	assertEquals(expected.trim(), report.trim());
    }
}