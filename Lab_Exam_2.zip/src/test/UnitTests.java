package test;

import solution.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UnitTests {

	@Test
	void checkHeirarchy() {
		Class<StringEvaluation> se = StringEvaluation.class;
		assertEquals(Object.class, 
				se.getSuperclass(), 
				"StringEvaluation shouldn't have an explicit superclass");
		
		Class<StringLengthEvaluation> sle = StringLengthEvaluation.class;
		assertEquals(StringEvaluation.class, 
				sle.getSuperclass(), 
				"StringLengthEvaluation should extend StringEvaluation");
		
		Class<StringVowelEvaluation> sve = StringVowelEvaluation.class;
		assertEquals(StringEvaluation.class, 
				sve.getSuperclass(), 
				"StringVowelEvaluation should extend StringEvaluation");
		
		Class<StringVowelRatioEvaluation> svre = 
				StringVowelRatioEvaluation.class;
		assertEquals(StringVowelEvaluation.class, 
				svre.getSuperclass(), 
				"StringVowelRatioEvaluation should extend StringVowelEvaluation");
	}
	
	@Test
	void testStringEvaluation() {
		StringEvaluation se = new StringEvaluation();
		se.setEvaluationString("AAAAA");
		assertEquals("This string is AAAAA", se.getEvaluation());
	}
	
	@Test
	void testStringLengthEvaluation() {
		StringEvaluation se = new StringLengthEvaluation();
		se.setEvaluationString("AAAAA");
		assertEquals("The string is 5 characters long", se.getEvaluation());
		
		se.setEvaluationString("A");
		assertEquals("The string is 1 characters long", se.getEvaluation());
		
		se.setEvaluationString("");
		assertEquals("The string is 0 characters long", se.getEvaluation());
	}
	
	
	@Test
	void testStringVowelEvaluation() {
		StringEvaluation se = new StringVowelEvaluation();
		se.setEvaluationString("BBBAA");
		assertEquals("The string has 2 vowels", se.getEvaluation());
		
		se.setEvaluationString("AAAAA");
		assertEquals("The string has 5 vowels", se.getEvaluation());
		
		se.setEvaluationString("BBBBB");
		assertEquals("The string has 0 vowels", se.getEvaluation());
	}
	
	@Test
	void testStringVowelRatioEvaluation() {
		StringEvaluation se = new StringVowelRatioEvaluation();
		se.setEvaluationString("BBBAA");
		assertEquals("The string has 40.00% vowels", se.getEvaluation());
		
		se.setEvaluationString("AAAAA");
		assertEquals("The string has 100.00% vowels", se.getEvaluation());
		
		se.setEvaluationString("BBBBB");
		assertEquals("The string has 0.00% vowels", se.getEvaluation());
	}
	
	@Test
	void testCountVowels() {
		StringVowelEvaluation se = new StringVowelEvaluation();
		se.setEvaluationString("BBBAA");
		assertEquals(2, se.countVowels());
		
		se.setEvaluationString("AAAAA");
		assertEquals(5, se.countVowels());
		
		se.setEvaluationString("BBBBB");
		assertEquals(0, se.countVowels());
	}
	
	@Test
	void testVowelRatio() {
		StringVowelRatioEvaluation se = new StringVowelRatioEvaluation();
		se.setEvaluationString("BBBAA");
		assertEquals(0.4, se.calculateRatio(), 0.0001);
		
		se.setEvaluationString("AAAAA");
		assertEquals(1.0, se.calculateRatio(), 0.0001);
		
		se.setEvaluationString("BBBBB");
		assertEquals(0.0, se.calculateRatio(), 0.0001);
	}
	
}


